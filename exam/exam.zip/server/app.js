// alternative entry point. Needs to be added to package.json if being used
