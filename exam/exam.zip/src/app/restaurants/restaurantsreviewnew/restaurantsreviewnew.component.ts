import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurantsreviewnew',
  templateUrl: './restaurantsreviewnew.component.html',
  styleUrls: ['./restaurantsreviewnew.component.css']
})
export class RestaurantsreviewnewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
