import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurantsreview',
  templateUrl: './restaurantsreview.component.html',
  styleUrls: ['./restaurantsreview.component.css']
})
export class RestaurantsreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
