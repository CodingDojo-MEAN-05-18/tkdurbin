export class Restaurant {
  _id: string;
  name: string;
  cuisine: string;


  constructor() {
    // this.id = Math.round(Math.random() * 1000);
  }

}
